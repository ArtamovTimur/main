-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 05 2017 г., 23:18
-- Версия сервера: 5.5.53
-- Версия PHP: 5.6.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `mag`
--

-- --------------------------------------------------------

--
-- Структура таблицы `rom_images`
--

CREATE TABLE `rom_images` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Структура таблицы `rom_orders`
--

CREATE TABLE `rom_orders` (
  `id` int(11) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_city` varchar(255) NOT NULL,
  `user_country` varchar(255) NOT NULL,
  `user_mail_index` varchar(255) NOT NULL,
  `user_phone` varchar(255) NOT NULL,
  `payment_status` enum('0','1') NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `rom_orders`
--

INSERT INTO `rom_orders` (`id`, `product_id`, `user_name`, `user_email`, `user_address`, `user_city`, `user_country`, `user_mail_index`, `user_phone`, `payment_status`, `order_date`) VALUES
(3, '-1', '1', '2', '3', '4', 'kz', '', '', '0', '2017-10-27 07:48:53'),
(4, '-1-2', 'tima', 'tima@mail.ru', 'arinova', 'aktobe', 'kz', '', '', '0', '2017-10-27 07:49:50');

-- --------------------------------------------------------

--
-- Структура таблицы `rom_preview_img`
--

CREATE TABLE `rom_preview_img` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rom_preview_img`
--

INSERT INTO `rom_preview_img` (`id`, `product_id`, `image`) VALUES
(21, 0, 'assets/img/products/FG6Z4Z5A/additional/RYS6dSit.jpg'),
(22, 0, 'assets/img/products/bt3ietiR/additional/2n76KhzZ.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `rom_products`
--

CREATE TABLE `rom_products` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` int(11) NOT NULL,
  `discount_price` int(11) NOT NULL,
  `suit_product_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `pub_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Структура таблицы `rom_users`
--

CREATE TABLE `rom_users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('1','2','3') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `rom_users`
--

INSERT INTO `rom_users` (`id`, `login`, `password`, `role`) VALUES
(1, 'tima', 'tima', '1');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `rom_images`
--
ALTER TABLE `rom_images`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rom_orders`
--
ALTER TABLE `rom_orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rom_preview_img`
--
ALTER TABLE `rom_preview_img`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rom_products`
--
ALTER TABLE `rom_products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rom_users`
--
ALTER TABLE `rom_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `rom_images`
--
ALTER TABLE `rom_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `rom_orders`
--
ALTER TABLE `rom_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `rom_preview_img`
--
ALTER TABLE `rom_preview_img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT для таблицы `rom_products`
--
ALTER TABLE `rom_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT для таблицы `rom_users`
--
ALTER TABLE `rom_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
