<?php
	function action_product()
	{
		$product = getProductById($_GET['id']);
		$images = getPreviewImagesById($_GET['id']);
		renderView('product', ['product' => $product, 'images' => $images]);
	}

	function action_add()
	{

		$in_cart = explode('-', $_COOKIE['incart']);
		$product_count = $_POST['product_count'];

		if(!in_array($_POST['id'], $in_cart))
		{
			$new_cookie = $_COOKIE['incart'] .= ('-' . $_POST['id']);
			$pcount = $_COOKIE['pcount'] .= ('-' . $product_count);
			setcookie('pcount', $pcount, time()+3600, '/');
			setcookie('incart', $new_cookie, time()+3600, '/');
			echo json_encode(['product' => getProductById($_POST['id']), 'count' => $product_count]);	
		}else {
			json_encode(['error' => 'Уже в корзине!']);
		}
		
	}

	function action_getProducts()
	{	
		$old = $_POST['last_id'];
		$products = getProductsByCount($old, 6);
		if(!empty($products)) {
			echo json_encode($products);
		}
	}

	function action_cartProducts()
	{
		$in_cart = explode('-', $_COOKIE['incart']);
		for($i = 1; $i <= count($in_cart)-1; $i++)
		{
			$products[] = getProductById($in_cart[$i]);	
		}
		if(!empty($products)){ echo json_encode($products); }

	}

	function action_deleteCart()
	{	
		$in_cart = explode('-', $_COOKIE['incart']);
		$in_cart = array_flip($in_cart);
		unset($in_cart[$_POST['id']]);
		$new_cookie = array_flip($in_cart);
		$new_cookie = implode('-', $new_cookie);
		setcookie('incart', $new_cookie, time()+3600, '/');

		$pcount = explode('-', $_COOKIE['pcount']);
		unset($pcount[count($pcount)-1]);
		$pcount = implode('-', $pcount);
		setcookie('pcount', $pcount, time()+3600, '/');
	}

	function action_order()
	{
		renderView('order', []);
	}

	function action_delivery()
	{
		renderView('delivery', []);
	}


	function action_test()
	{
		echo 'test';
	}
?>