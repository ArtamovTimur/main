<?php
	function action_getImages()
	{
		
	}

?>