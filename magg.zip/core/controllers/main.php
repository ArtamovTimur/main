<?php
	function action_index()
	{
		if($_SERVER['REQUEST_URI'] == '/'){
			header('Location: /main/index');	
		}
		renderView('index', []);
	}
	function action_about()
	{
		renderView('about', []);
	}
	function action_magazine()
	{
		$all_product = getAllProducts();
		renderView('magazine', ['all_products' => $all_product]);
	}
	function action_payment()
	{
		renderView('payment', []);
	}
	function action_care()
	{	
		renderView('care', []);
	}
	function action_franchise()
	{
		renderView('franchise', []);
	}
	function action_test()
	{
		echo 'test';
	}
?>