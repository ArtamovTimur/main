<?php
	function action_login()
	{

	}

	function action_logout()
	{
		unset($_SESSION['auth']);
		session_destroy();
		header('Location: /admin');
	}

	function action_index()
	{
		if($_SESSION['auth']){
			header('Location: /admin/main');
		}
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{	
			$formData = [
				'login' => htmlspecialchars(trim($_POST['admin_login'])),
				'password' => htmlspecialchars(trim($_POST['admin_password']))
			];
			if(!empty($formData['login']) && !empty($formData['password']))
			{
				if(checkAdmin($formData['login'], $formData['password'])){
					$_SESSION['auth'] = true;
					header('Location: /admin/main');
				}else {
					renderAdmin('index', ['errors' => ['Неверный логин или парооль!']]);
				}
			}else {
				renderAdmin('index', ['errors' => ['Заполните все поля!']]);
			}
			
		}else {
			renderAdmin('index', []);
		}
	}
	function action_main()
	{
		if($_SESSION['auth']){
			$all_products = getAllProducts();
			renderAdmin('main', ['all_products' => $all_products]);
		}else {
			header('Location: /admin');
		}
	}
	function action_orders()
	{

	}
	function action_users()
	{

	}
	function action_products()
	{

	}
	function action_addProduct()
	{
		if(!$_SESSION['auth'])
		{ header('Location: /admin'); }
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$formData = [
				'new_product_title' => htmlspecialchars(trim($_POST['new_product_title'])),
				'new_product_description' => htmlspecialchars(trim($_POST['new_product_description'])),
				'new_product_price' => htmlspecialchars(trim($_POST['new_product_price'])),
				'new_product_discount_price' => htmlspecialchars(trim($_POST['new_product_discount_price']))
			];
			$product_img_name = generateString() . '.' .end(explode(".", $_FILES['new_product_main_image']['name']));
			$folder_name = generateString();
			$formData['new_product_main_image'] = 'assets/img/products/'.$folder_name . '/' . $product_img_name;


			if(checkForm($formData))
			{
				if(mkdir('assets/img/products/' . $folder_name))
				{
					mkdir('assets/img/products/' . $folder_name . '/additional');


					$imgArr = $_FILES['new_product_additional_img'];

					$folderName = $folder_name;
					$lastId = getLastProductId()[0]['id']+1;
					

					for($i = 0; $i <= count($imgArr); $i++)
					{
						
						if($_FILES['new_product_additional_img']['name'][$i] !== '')
						{
							
							$photoName = generateString() . '.' .end(explode(".", $_FILES['new_product_additional_img']['name'][$i]));
							move_uploaded_file($_FILES['new_product_additional_img']['tmp_name'][$i],
										'assets/img/products/' . $folderName . '/additional/' . $photoName);
							addProductAdditionalPhoto($lastId, 'assets/img/products/' . $folderName . '/additional/' . $photoName);
						}
					}





					if(addProductPhoto($folder_name, $product_img_name))
					{
						addNewProduct($formData);
						header('Location: /admin');
					}else {
						echo 'Ошибка загрузки изобрадение';
					}
				}else {
						echo 'Ошибка загрузки изобрадение';
				}
			}else {
				renderAdmin('add_product', ['errors' => ['Не все поля заполнены!']]);
			}
			
		}else {
			renderAdmin('add_product', []);
		}
	}
	function action_deleteProduct()
	{
		$id = $_GET['id'];
		$folderName = explode('/', getMainImageById($id)[0]['image']);
		$folderName = $folderName[count($folderName)-2];
		removeDirectory('assets/img/products/' . $folderName);
		deleteProductById($id);
		header('Location: /admin');
	}

	function action_updateProduct()
	{
		$id = $_GET['id'];
		if($_SERVER['REQUEST_METHOD'] == 'POST')
		{
			$id = $_POST['update_id'];
			$formData = [
				'title' => htmlspecialchars(trim($_POST['product_title'])),
				'description' => htmlspecialchars(trim($_POST['product_description'])),
				'price' => htmlspecialchars(trim($_POST['product_price'])),
				'discount_price' => htmlspecialchars(trim($_POST['product_discount_price']))
			];
			
			if($_FILES['product_main_image']['name'] !== '') 
			{ 
				$folderName = explode('/', getMainImageById($id)[0]['image']);
				unlink(getMainImageById($id)[0]['image']);
				$folderName = $folderName[count($folderName)-2];
				$product_img_name = generateString() . '.' .end(explode(".", $_FILES['product_main_image']['name']));
				$formData['image'] = 'assets/img/products/'.$folderName . '/' . $product_img_name;
				updateProductPhoto($folderName, $product_img_name);
			}


			if(updateProductById($id, $formData)){
				header('Location: /admin');
			}else {
				echo 'Update error';
			}
		}
		$product_data = getProductById($id);
		renderAdmin('update_product', ['product_data' => $product_data]);
	}

	function action_images()
	{

	}
	function action_addImages()
	{

	}
	function action_deleteImage()
	{

	}
	function action_allOrders()
	{
		$all_orders = getAllOrders();
		renderAdmin('orders', ['all_orders' => $all_orders]);
	}
	function action_test()
	{
		var_export(getPreviewImagesById(18));
	}
?>