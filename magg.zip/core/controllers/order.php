<?php
	function action_add()
	{
		$form_data = [
			'product_id' => $_COOKIE['incart'],
			'user_name' => htmlspecialchars(trim($_POST['user_name'])),
			'user_email' => htmlspecialchars(trim($_POST['user_email'])),
			'user_address' => htmlspecialchars(trim($_POST['user_address'])),
			'user_city' => htmlspecialchars(trim($_POST['user_city'])),
			'user_country' => htmlspecialchars(trim($_POST['user_country'])),
			'user_mail_index' => htmlspecialchars(trim($_POST['user_mail_index'])),
			'user_phone' => htmlspecialchars(trim($_POST['user_phone']))
		];
		if(checkForm($form_data))
		{
			$str = generateString();
			$form_data['key'] = $str;
			addNewOrder($form_data);
			echo $str;
		}else {
			echo 'Заполните все поля!';
		}
		
	}

	function action_delete()
	{
		if(!empty($_POST['special']))
			$key = $_POST['special'];
			if(deleteOrderByKey($key)){
				echo 'Ok';
			}
	}

	function action_good()
	{
		if(!empty($_POST['special']))
			$key = $_POST['special'];
		if(goodPayment($key)){
				echo 'Ok';
			}
	}


?>