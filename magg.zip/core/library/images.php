<?php
function addProductPhoto($folderName, $photoName)
	{
		if(isset($_FILES['new_product_main_image']))
		{
					if($_FILES['new_product_main_image']['error'] == 0)
					{
						$res = move_uploaded_file($_FILES['new_product_main_image']['tmp_name'],
							'assets/img/products/' . $folderName . '/' . $photoName);
						return true;
					}
					else 
					{
						return false;
					}
		}
		else 
		{
			return false;
		}
	}

	function updateProductPhoto($folderName, $photoName)
	{
		if(isset($_FILES['product_main_image']))
		{
					if($_FILES['product_main_image']['error'] == 0)
					{
						$res = move_uploaded_file($_FILES['product_main_image']['tmp_name'],
							'assets/img/products/' . $folderName . '/' . $photoName);
						return true;
					}
					else 
					{
						return false;
					}
		}
		else 
		{
			return false;
		}
	}

	
?>