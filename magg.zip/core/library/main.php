<?php
	function getUrlSegment($n)
	{
		$url = explode('/', strtolower($_GET['url']));
		return $url[$n];
	}

	function show404page()
	{
		echo '404';
	}

	function renderView($view, $data = [])
	{
		require "core/views/layouts/" . $view . ".php";
	}

	function generateString($length = 8){
 		 $chars = 'abdefhiknrstyzABDEFGHKNQRSTYZ23456789';
  		$numChars = strlen($chars);
  		$string = '';
  		for ($i = 0; $i < $length; $i++) {
  		  $string .= substr($chars, rand(1, $numChars) - 1, 1);
  		}
 		 return $string;
	}

	function checkForm($form_data)
	{
		foreach ($form_data as $value) {
			if(!isset($value) || empty($value) || is_null($value)){
				return false;
			}
		}	
		return true;
	}

	function dirDel($dir) 
	{  
	    $d=opendir($dir);  
	    while(($entry=readdir($d))!==false) 
	    { 
	        if ($entry != "." && $entry != "..") 
	        { 
	            if (is_dir($dir."/".$entry)) 
	            {  
	                dirDel($dir."/".$entry);  
	            } 
	            else 
	            {  
	                unlink ($dir."/".$entry);  
	            } 
	        } 
	    } 
	    closedir($d);  
	    rmdir ($dir);  
	} 

	 function removeDirectory($dir)
	 {
	    if ($objs = glob($dir."/*")) {
	       foreach($objs as $obj) {
	         is_dir($obj) ? removeDirectory($obj) : unlink($obj);
	       }
	    }
	    rmdir($dir);
  	}

?>