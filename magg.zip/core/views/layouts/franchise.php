	<?php require 'core/views/templates/header.tpl'; ?>

	<div class="franchise-content-img">
		<div class="franchise-text-block">
			<div class="franchise-text">
				<h1>Франшиза «ROMANTIC»</h1>
				<p>
					Успешная модель цветочного бизнеса, которая теперь доступна для каждого. Мы работаем с теми, кто готов влиться в проект с головой и развивать его, не останавливаясь на достигнутом, открывая новые цветочные салоны, увеличивая наше присутствие по всему Миру.
				</p>
			</div>
			<div class="franchise-form">
				<div class="form">
					 <div class="treaInput">
					 	<input type="text" placeholder="Имя">
					 	<input type="text" placeholder="Email">
					 	<input type="text" placeholder="Телефон">
					 	<input type="text" placeholder="Тема">
					 </div>
					 <div class="textarea">
					 	<textarea name="" id="" placeholder="Сообщения"></textarea>
					 	<button id="send_btn">Отправить</button>
					 </div>
				</div>
			</div><!-- franchise form end -->
		</div>
	</div><!-- franchise form end -->
	<div class="description-wrap">
		<div class="franchise-description">
			<div class="about-franchise">
				<h2>О франшизе</h2>
				<p>
					«ROMANTIC» — это приятная возможность для многих любителей цветов насладиться любимым делом, почувствовать ритм жизни и даже сделать невозможное. Став владельцем цветочного салона под ключ, входящего в нашу сеть, Вы просто перешагиваете те проблемы, которые бывают у предпринимателей, начиная бизнес с нуля. Это не только купить готовый бизнес, это значит стать членом сильной команды ROMANTIC, большой семьи, объединенной одним именем, одной системой поставок, одинаковым подходом к работе, близким по духу дизайном, похожим стилем и обслуживанием.
				</p>
			</div>
			<div class="franchise-salary">
				<h2>Средние показатели</h2>
				<p>
					<div class="black-bg">Чистая прибыль: 2 000 000 – 3 000 000 тенге.</div>
					<div class="black-bg">Стоимость франшизы: 5 000 000 тенге.</div>
					<div class="black-bg">Окупаемость франшизы: 3 – 4 месяца.</div>
				</p>
			</div>
		</div>
	</div><!-- description-wrap -->
	<div class="why-romantic">
		Почему «ROMANTIC»?
	</div>



	<div class="slider-wrap">
		<div class="slider">
		  <div class="bd">
		    <ul>
		      <li><img src="/assets/img/slider/img1.webp" /></li>  
		      <li><img src="/assets/img/slider/img2.webp" /></li>
		      <li><img src="/assets/img/slider/img3.webp" /></li>
		      <li><img src="/assets/img/slider/img4.webp" /></li>
		      <li><img src="/assets/img/slider/img5.webp" /></li>
		      <li><img src="/assets/img/slider/img6.webp" /></li>
			  <li><img src="/assets/img/slider/img7.webp" /></li>
		      <li><img src="/assets/img/slider/img8.webp" /></li>
		    </ul>
		  </div>
  <div class="hd">
    <ul>
    </ul>
  </div>
  <div class="pnBtn prev"> <span class="blackBg"></span> <a class="arrow" href="javascript:void(0)"></a> </div>
  <div class="pnBtn next"> <span class="blackBg"></span> <a class="arrow" href="javascript:void(0)"></a> </div>
</div>
<script type="text/javascript">
jQuery(".slider .bd li").first().before( jQuery(".slider .bd li").last() );
jQuery(".slider").hover(function(){
	 jQuery(this).find(".arrow").stop(true,true).fadeIn(300) 
	 },function(){ 
	 	jQuery(this).find(".arrow").fadeOut(300) });				
	 jQuery(".slider").slide(
	 	{ titCell:".hd ul", mainCell:".bd ul", effect:"leftLoop",autoPlay:true, vis:3,autoPage:true, trigger:"click"}
	);
</script>
	</div>




	<?php require 'core/views/templates/footer.tpl'; ?>