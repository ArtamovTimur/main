<?php require 'core/views/templates/header.tpl'; ?>


<div class="order-wrap">
	<div class="main-price-wrap">Товаров на сумму: <span id="mmm"><span></div>
	<div class="order-title">Куда доставить заказ?</div>
	<form action="/order/add" method="post">
		
		<div class="user_name">Ваши имя и фамилия</div>
		<input type="text" name="user_name">
		<div class="user_email">Эл. почта (мы дорожим вашей <br>конфиденциальностью)</div>
		<input type="mail" name="user_email">
		<div class="user_address">Улица, № дома, № кв.</div>
		<input type="text" name="user_address">
		<div class="user_city">Город</div>
		<input type="text" name="user_city">
		<div class="user_country">Страна</div>
		<select name="user_country" id="user_country">
			<option value="kz">Казахстан</option>
			<option value="ru">Россия</option>
		</select>
		<div class="user_mail_index">Почтовый индекс</div>
		<input type="text" name="user_mail_index">
		<div class="user_phone">Номер телефона</div>
		<input type="text" name="user_phone">
		<br><br>
		<button id="send-order">Продолжить</button>
	</form>

</div>

<script>
	$('#send-order').click(function(e){
		e.preventDefault();
		$.ajax({
		url: '/order/add',
		type: 'POST',
		dataType: 'html',
		data: {
			'user_name': $('input[name="user_name"]').val(),
			'user_email': $('input[name="user_email"]').val(),
			'user_address': $('input[name="user_address"]').val(),
			'user_city': $('input[name="user_city"]').val(),
			'user_country': $('#user_country').val(),
			'user_mail_index': $('input[name="user_mail_index"]').val(),
			'user_phone': $('input[name="user_phone"]').val()
		},
		})
		.done(function(data) {
			console.log("success");
			console.log(data);
			if(data == 'Заполните все поля!') { alert('Заполните все поля!')}
				else {localStorage.setItem('special', data); document.location.href='/products/delivery'; }		
			
		})
		.fail(function() {
			console.log("error");
		})
		.always(function() {
			console.log("complete");
		});
	});
	
	
</script>



<?php require 'core/views/templates/footer.tpl'; ?>