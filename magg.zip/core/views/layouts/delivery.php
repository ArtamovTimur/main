	<?php require 'core/views/templates/header.tpl'; ?>
<script src="https://widget.cloudpayments.ru/bundles/cloudpayments"></script>
		<div class="main-price-wrap">Товаров на сумму: <span id="mmm"><span></div>
		<button id="send-order">Оплатить</button>



	<script type="text/javascript">
	$('#send-order').click(function(e){
		e.preventDefault();
	});
  var payHandler = function () {
        //требуется библиотека jquery
        var widget = new cp.CloudPayments();
        widget.charge({ // options
                publicId: 'pk_aa60a77b2ccb3c530bfae4688986b',
                description: 'Оплата в flora24.kz',
                amount: parseInt($('#mmm').html()), //сумма
                currency: 'KZT',
                invoiceId: localStorage.getItem('special'), //номер заказа
                accountId: 'user@example.com', //плательщик
            },
            function (options) { // success
               	alert('Платеж прошел успешно!');
               		$.ajax({
               		url: '/order/good',
               		type: 'POST',
               		dataType: 'html',
               		data: {'special': localStorage.getItem('special')},
               	})
               	.done(function(data) {
               		console.log("success");
               		console.log(data);
               	})
               	.fail(function() {
               		console.log("error");
               	})
               	.always(function() {
               		console.log("complete");
               	});
            },
            function (reason, options) { // fail
               	alert('Ивините произошла ошибка!');
               	$.ajax({
               		url: '/order/delete',
               		type: 'POST',
               		dataType: 'html',
               		data: {'special': localStorage.getItem('special')},
               	})
               	.done(function(data) {
               		console.log("success");
               		console.log(data);
               	})
               	.fail(function() {
               		console.log("error");
               	})
               	.always(function() {
               		console.log("complete");
               	});
            });
    };
    $("#send-order").on("click", payHandler); //кнопка "Оплатить"
</script>




	<?php require 'core/views/templates/footer.tpl'; ?>