<?php require 'core/views/templates/header.tpl'; ?>

		<div class="header-slider">
			<div class="slider-title"><strong><a href="/main/magazine">Перейти в магазин</a></strong></div>
			<div class="slider-text">
				<span>
					<strong class="golland-rose">Голландские розы</strong><br>
				от 399 тенге <br>
				с доставкой по Актобе <br>
				за 29 минут <br>	
				</span>
				
			</div>
		</div>

		<div class="two-bloc-wrap">
			<div class="video clearfix">
				<iframe width="968" height="524" src="https://www.youtube.com/embed/fXfLLXhcgy4" frameborder="0" allowfullscreen></iframe>
			</div>
			<div class="line">
				<span class="sq">■</span>
				<span class="sq">■</span>
				<span class="sq">■</span>
			</div>
			<div class="vitrine-title">Наши композиции</div>
			<div class="free">
				<div class="free-photo">
					Бесплатное фото<br>
					<small><small>момента вручения</small></small>
				</div>
				<div class="free-delivery">
					Бесплатная доставка<br>
					<small><small>от 5000 тенге</small></small>
				</div>
				<div class="free-card">
					Бесплатная открытка<br>
					<small><small>с Вашим  посланием</small></small>
					
				</div>
			</div>
		<div class="gallery">

				<div class="ll">
					<a href="/assets/img/img1.webp" class="flipLightBox">
					<img src="/assets/img/img1.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img2.webp" class="flipLightBox">
					<img src="/assets/img/img2.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img3.webp" class="flipLightBox">
					<img src="/assets/img/img3.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img4.webp" class="flipLightBox">
					<img src="/assets/img/img4.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img5.webp" class="flipLightBox">
					<img src="/assets/img/img5.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img6.webp" class="flipLightBox">
					<img src="/assets/img/img6.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img7.webp" class="flipLightBox">
					<img src="/assets/img/img7.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img8.webp" class="flipLightBox">
					<img src="/assets/img/img8.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img9.webp" class="flipLightBox">
					<img src="/assets/img/img9.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>
				
				 

				
		</div><!-- gallery end -->




		<div class="gallery" id="gallery-two">

				<div class="ll">
					<a href="/assets/img/img10.webp" class="flipLightBox">
					<img src="/assets/img/img10.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img11.webp" class="flipLightBox">
					<img src="/assets/img/img11.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img12.webp" class="flipLightBox">
					<img src="/assets/img/img12.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img13.webp" class="flipLightBox">
					<img src="/assets/img/img13.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img14.webp" class="flipLightBox">
					<img src="/assets/img/img4.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img15.webp" class="flipLightBox">
					<img src="/assets/img/img15.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img16.webp" class="flipLightBox">
					<img src="/assets/img/img16.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img17.webp" class="flipLightBox">
					<img src="/assets/img/img17.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img18.webp" class="flipLightBox">
					<img src="/assets/img/img18.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>
				
				 

				
		</div><!-- gallery end -->


		<div class="gallery" id="gallery-three">

				<div class="ll">
					<a href="/assets/img/img19.webp" class="flipLightBox">
					<img src="/assets/img/img19.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img20.webp" class="flipLightBox">
					<img src="/assets/img/img20.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img21.webp" class="flipLightBox">
					<img src="/assets/img/img21.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img22.webp" class="flipLightBox">
					<img src="/assets/img/img22.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img23.webp" class="flipLightBox">
					<img src="/assets/img/img23.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img24.webp" class="flipLightBox">
					<img src="/assets/img/img24.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img25.webp" class="flipLightBox">
					<img src="/assets/img/img25.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img26.webp" class="flipLightBox">
					<img src="/assets/img/img26.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img27.webp" class="flipLightBox">
					<img src="/assets/img/img27.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>
				
				 
		</div><!-- gallery end -->


		<div class="gallery" id="gallery-four">

				<div class="ll">
					<a href="/assets/img/img28.webp" class="flipLightBox">
					<img src="/assets/img/img28.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img29.webp" class="flipLightBox">
					<img src="/assets/img/img29.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img30.webp" class="flipLightBox">
					<img src="/assets/img/img30.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img31.webp" class="flipLightBox">
					<img src="/assets/img/img31.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img32.webp" class="flipLightBox">
					<img src="/assets/img/img32.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img33.webp" class="flipLightBox">
					<img src="/assets/img/img33.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img34.webp" class="flipLightBox">
					<img src="/assets/img/img34.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img35.webp" class="flipLightBox">
					<img src="/assets/img/img35.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img36.webp" class="flipLightBox">
					<img src="/assets/img/img36.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>
				
				 
		</div><!-- gallery end -->


		<div class="gallery" id="gallery-five">

				<div class="ll">
					<a href="/assets/img/img37.webp" class="flipLightBox">
					<img src="/assets/img/img37.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img38.webp" class="flipLightBox">
					<img src="/assets/img/img38.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img39.webp" class="flipLightBox">
					<img src="/assets/img/img39.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img40.webp" class="flipLightBox">
					<img src="/assets/img/img40.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img41.webp" class="flipLightBox">
					<img src="/assets/img/img41.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img43.webp" class="flipLightBox">
					<img src="/assets/img/img43.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>


				<div class="ll">
					<a href="/assets/img/img44.webp" class="flipLightBox">
					<img src="/assets/img/img44.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>101 Голландская роза</span>
					</a>
				</div>
				
				  

				<div class="ll">
					<a href="/assets/img/img45.webp" class="flipLightBox">
					<img src="/assets/img/img45.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 голландских роз в фирменной коробке</span>
					</a>
				</div>
				
				 

				<div class="ll">
					<a href="/assets/img/img46.webp" class="flipLightBox">
					<img src="/assets/img/img46.webp" width="315" height="300" alt="flipLightBox Image 1" />
					<span>25 Красных роз в квадратной коробке</span>
					</a>
				</div>
				
				 
		</div><!-- gallery end -->



		<div class="all-img">Показать еще картинки</div>
		<div class="line">
			<span class="sq">■</span>
			<span class="sq">■</span>
			<span class="sq">■</span>
		</div>
		<div class="price-list"></div>
		<div class="line">
			<span class="sq">■</span>
			<span class="sq">■</span>
			<span class="sq">■</span>
		</div>
		<div class="assortiment-wrap">
			<img src="/assets/img/assortiments.png" alt="">
			<div class="assortiment">
				<div class="rose-block">
				<div class="description">
					<strong>В коробке SMALL "ROMANTIC"</strong><br>
					9 роз - 8400 тенге<br>
					11 роз - 9600 тенге<br>
					13 роз - 10800 тенге<br>
					15 роз - 12000 тенге<br>
					17 роз - 13200 тенге 
				</div>
			</div>
			<div class="rose-block">
				<img src="" alt="">
				<div class="description">
					<strong>В коробке MEDIUM "ROMANTIC"</strong><br>
					19 роз - 14400 тенге<br>
					21 роза - 15600 тенге<br>
					23 розы - 16800 тенге<br>
					25 роз - 18000 тенге<br>
					27 роз - 19200 тенге<br>
					29 роз - 20400 тенге<br>
					31 роза - 21600 тенге
				</div>
			</div>
			<div class="rose-block">
				<img src="" alt="">
				<div class="description">
					<strong>В коробке BIG "ROMANTIC"</strong><br>
					33 розы - 22800 тенге<br>
					35 роза - 24000 тенге<br>
					37 розы - 25200 тенге<br>
					39 роз - 26400 тенге<br>
					41 роза - 27600 тенге<br>
					43 розы - 28800 тенге<br>
					45 роз - 30000 тенге<br>
					47 роз - 31200 тенге<br>
					49 роз - 32400 тенге<br>
					51 роза - 33600 тенге
				</div>
			</div>
		</div><!-- assortiments end -->
	 </div><!-- assortiments wrap end -->
	 <div class="line">
			<span class="sq">■</span>
			<span class="sq">■</span>
			<span class="sq">■</span>
		</div>
		<div class="assortiment-wrap">
			<img src="/assets/img/assortiments2.png" alt="">
			<div class="assortiment">
				<div class="rose-block">
				<div class="description">
					<strong>Сборные цветы в коробке</strong><br>
					от 7990 тенге
				</div>
			</div>
			<div class="rose-block">
				<img src="" alt="">
				<div class="description">
					<strong>Сборные и экзотические букеты</strong><br>
					SMALL - от 2990 тенге<br>
					MEDIUM - от 9990 тенге<br>
					BIG - от 14990 тенге
				</div>
			</div>
			<div class="rose-block">
				<img src="" alt="">
				<div class="description">
					<strong>Букет МАМА</strong><br>
					47800 тенге
				</div>
			</div>
		</div><!-- assortiments end -->
	 </div><!-- assortiments wrap end -->
	 <div class="line">
	 	<div class="go-to-top">НАВЕРХ</div>
	 </div>
	 <div class="contacts-line-title">
	 	<span>Контакты</span>
	 </div>
	 <div class="map">
	 	 <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A278c28d59b7d42e70c8c45212763ea0dcca6c9ba00463518479954b90e68f8f8&amp;width=100%&amp;lang=ru_RU&amp;scroll=true"></script>
	 </div>
	</div><!-- two block end -->
		<div class="formAndText">
				<div class="footerText">
					<h3>НАШ АДРЕС:</h3> <br>
					<p>
						Улица Маресьева 48. (Круглосуточно). <br>
						(Цветы, комнатные растения, гелиевые шары, сладости, <br>
						 мягкие игрушки).
					</p>
					<br>
					<h3>Наши контакты:</h3> <br>
					<p>
						8 (707) 544-42-66 (WhatsApp) <br>
						8 (707) 944-42-66 (WhatsApp) <br>
						Почта: <a href="">info@romantic04.kz</a>
					</p>
				</div>
				<div class="first-form">
					 <div class="treaInput">
					 	<input type="text" placeholder="Имя">
					 	<input type="text" placeholder="Email">
					 	<input type="text" placeholder="Телефон">
					 	<input type="text" placeholder="Тема">
					 </div>
					 <div class="textarea">
					 	<textarea name="" id="" placeholder="Сообщения"></textarea>
					 	<button id="send_btn">Отправить</button>
					 </div>

				</div>
		</div>

		<?php require 'core/views/templates/footer.tpl'; ?>