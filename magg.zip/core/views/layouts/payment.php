	<?php require 'core/views/templates/header.tpl'; ?>
	<h2 class="payment-title">
			Оплатить доставку цветов в Актобе на расстоянии Вы можете следующими способами:
	</h2>
	<div class="content-payment">
		
		<div class="payment">
			<p>
				1. Карта Visa Альфа банка Казахстан<br>
			    4269 0495 2596 0030 <br>		
			    Cчет: KZ349470398989898487<br>
			    ИИН: 970131350014 Бондаренко Дмитрий Александрович<br>
			   	<br><br>
			    Карта Visa KAZKOM <br>
			    4003 0327 3469 9368<br>
			    Счет: KZ21926005PN01800941<br>
			    ИИН: 970131350014 Бондаренко Дмитрий Александрович<br>
			 	<br><br>
			    Карта Visa HALYK BANK<br>
			    4402 5735 1916 1998<br>
			    ИИН: 961009350582 Утениязов Марат Салимжанович<br>
			    <br><br>
			    2. Cчет Qiwi Wallet номер: 8 (707) 544-42-66 <br>
 
				3. Оплата через курьера при доставке цветов.<br>
 				<br><br>
				- Для подтверждения платежа, пожалуйста, сохраните чек перевода средств и отправьте его нам фотографией по
				  Whats'App на номер 8 (707) 544-42-66.<br>
				  <br><br>

			</p>
		</div>
		<div class="payment-img">
			<img src="/assets/img/alfa.webp" alt="alfa">
			<img src="/assets/img/kazkom.png" alt="kazkom">	
			<img src="/assets/img/halyk.webp" alt="halyk">
			<p>
				- Доставка цветов в Актобе при дистанционном заказе будет выполнена только при 100% оплате букета.<br>
				<br><br>
				- По Вашему желанию, мы можем сделать фотоотчет, доставленного букета<span class=""></span>
			</p>
		</div>

	</div>
	<?php require 'core/views/templates/footer.tpl'; ?>