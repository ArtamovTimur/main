<?php require 'core/views/templates/admin/header.tpl'; ?>
	<div class="add-product-wrap-title">Добавление нового товара</div>
	<div class="add-product-wrap">
		<form action="/admin/addProduct" method="post" enctype="multipart/form-data">
			<div class="new-product-title">Название товара</div>
			<input type="text" name="new_product_title">
			<div class="new-product-description">Описание товара(кратко)</div>
			<textarea name="new_product_description" id="" cols="30" rows="5"></textarea>
			<div class="new-product-price">Цена товара без скидки(только цифры)</div>
			<input type="number" name="new_product_price">
			<div class="new-product-discount-price">Цена товара со скидкой скидки(только цифры)</div>
			<input type="number" name="new_product_discount_price">
			<div class="new-product-main-image">Главная картинка товара</div>
			<input type="file" name="new_product_main_image">
			<div class="additional-images">Дополнительные катинки(не обязательно)</div>
			<input type="file" name="new_product_additional_img[]">
			<input type="file" name="new_product_additional_img[]">
			<input type="file" name="new_product_additional_img[]">
			<input type="file" name="new_product_additional_img[]">
			<input type="file" name="new_product_additional_img[]">
			<input type="file" name="new_product_additional_img[]">
			<br><br>
			<input type="submit" value="Добавить">
		</form>
	</div>
<?php require 'core/views/templates/admin/footer.tpl'; ?>