<?php require 'core/views/templates/admin/header.tpl'; ?>
	<?php 
		$orders = [];
		if(!empty($data['all_orders']))
		$orders = $data['all_orders'];
	?>
	<div class="order-title">Все заказы</div>
	<div class="orders-wrap">
		<table width="100%">
			<tr>
				<th>Имя клиента</th>
				<th>Email клиента</th>
				<th>Адрес</th>
				<th>Город</th>
				<th>Страна</th>
				<th>Почтовый индекс</th>
				<th>Телефон</th>
				<th>Статус оплаты</th>
				<th>Дата заказа</th>
			</tr>

			<?php for($i = 0; $i <= count($orders)-1; $i++):?>
				<tr>
					<td><?= $orders[$i]['user_name']; ?></td>
					<td><?= $orders[$i]['user_email']; ?></td>
					<td><?= $orders[$i]['user_address']; ?></td>
					<td><?= $orders[$i]['user_city']; ?></td>
					<td><?= $orders[$i]['user_country']; ?></td>
					<td><?= $orders[$i]['user_mail_index']; ?></td>
					<td><?= $orders[$i]['user_phone']; ?></td>
					<td><?php if($orders[$i]['payment_status'] == 0) echo 'Не оплачен'; else 
					echo 'Оплачен'; ?></td>
					<td><?= $orders[$i]['order_date']; ?></td>
				</tr>
			<?php endfor;?>

		</table>
	</div>

<?php require 'core/views/templates/admin/footer.tpl'; ?>