<?php
	$all_products = [];
	if(!empty($data['all_products'])){
		$all_products = $data['all_products'];
	}
?>
<?php require 'core/views/templates/admin/header.tpl'; ?>
		<div class="products-wrap-title">Все продукты</div>
		<div class="products-wrap">
			<?php for($i = 0; $i <= count($all_products)-1; $i++): ?>
			<div class="product">
				<div class="product-img">
					<img src="/<?= $all_products[$i]['image']; ?>" alt="" width="80%">
				</div>
				<div class="product-title">
					<?= $all_products[$i]['title']; ?>
				</div>
				<div class="product-description">
					<?= $all_products[$i]['description']; ?>
				</div>
				<div class="product-old-price"><?= $all_products[$i]['price']; ?>&nbsp;₸</div>
				<div class="product-price"><?= $all_products[$i]['discount_price'];?>&nbsp;₸</div>
				<div class="product-pub-date"><?= $all_products[$i]['pub_date']; ?></div>
				<div class="product-author"><?= $all_products[$i]['author']; ?></div>
				<div class="product-update"><a href="/admin/updateProduct?id=<?= $all_products[$i]['id']; ?>">Редактировать</a></div>
				<div class="product-delete"><a href="/admin/deleteProduct?id=<?= $all_products[$i]['id']; ?>">Удалить</a></div>
			</div>
			<?php endfor; ?>
		</div>
	</div><!-- wrap end -->
<?php require 'core/views/templates/admin/footer.tpl'; ?>