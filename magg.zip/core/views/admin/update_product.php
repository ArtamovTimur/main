<?php require 'core/views/templates/admin/header.tpl'; ?>
	<?php
		$product = [];
		if(!empty($data['product_data']))
			$product = $data['product_data'];
	?>
	<div class="add-product-wrap-title">Редактирование товара</div>
	<div class="add-product-wrap">
		<form action="/admin/updateProduct" method="post" enctype="multipart/form-data">
			<input type="hidden" name="update_id" value="<?= $product[0]['id'];?>">
			<div class="new-product-title">Название товара</div>
			<input type="text" name="product_title" value="<?= $product[0]['title'];?>">
			<div class="new-product-description">Описание товара(кратко)</div>
			<textarea name="product_description" id="" cols="30" rows="5"><?= $product[0]['description'];?></textarea>
			<div class="new-product-price">Цена товара без скидки(только цифры)</div>
			<input type="number" name="product_price" value="<?= $product[0]['price'];?>">
			<div class="new-product-discount-price">Цена товара со скидкой скидки(только цифры)</div>
			<input type="number" name="product_discount_price" value="<?= $product[0]['discount_price'];?>">

			<div class="new-product-main-image">Главная картинка товара</div>

			<img src="/<?= $product[0]['image'];?>" alt="" width="300" align="left">
			<div class="clear"></div>
			<input type="file" name="product_main_image">
			<div class="additional-images">Дополнительные катинки(не обязательно)</div>
			<input type="file" name="product_additional_img[]">
			<input type="file" name="product_additional_img[]">
			<input type="file" name="product_additional_img[]">
			<input type="file" name="product_additional_img[]">
			<input type="file" name="product_additional_img[]">
			<input type="file" name="product_additional_img[]">
			<br><br>
			<input type="submit" value="Сохранить">
		</form>
	</div>
<?php require 'core/views/templates/admin/footer.tpl'; ?>