<?php
	$errors = [];
	if(!empty($data['errors']))
		{ $errors = $data['errors']; }
	foreach($errors as $value) {
		echo '<h1 class="err">' . $value . '</h1>';
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="/assets/css/admin.css">
</head>
<body>
	<h1 class="login-title">Админ панель вход</h1>
	<div class="login-wrap">
		<form action="/admin/index" method="post">
			<h3 class="inplogin">Логин</h3>
			<input type="text" name="admin_login">
			<h3 class="inppass">Пароль</h3>
			<input type="password" name="admin_password"><br><br>
			<input type="submit" value="Войти" class="login">
		</form>
	</div>
	
	
</body>
</html>