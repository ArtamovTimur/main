<?php
	function getUserRoleByLoginAndPassword($userLogin, $userPassword)
	{
		$sql = "SELECT role FROM rom_users WHERE login='{$userLogin}' AND password='{$userPassword}'";
		$dbh = db_query($sql);
		return $dbh;
	}

?>