<?php
	function getAllProducts()
	{
		return db_get_data_from_table('rom_products');
	}
	
	function getProductById($id)
	{
		$sql = "SELECT * FROM rom_products WHERE id=$id";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function getProductsByCount($old, $count)
	{
		$sql = "SELECT * FROM rom_products LIMIT $old, $count";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function getFixedProductsByCount($count)
	{
		$sql = "SELECT * FROM rom_products LIMIT $count";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function addNewProduct($data = [])
	{
		$sql = "INSERT INTO rom_products (`title`, `image`, `description`, `price`, `discount_price`)
		VALUES ('{$data['new_product_title']}', '{$data['new_product_main_image']}','{$data['new_product_description']}', '{$data['new_product_price']}', '{$data['new_product_discount_price']}')";
		$res = db_query($sql);
		if(!$res){
			return false;
		}else { 
			return true;
		}
	}

	function getMainImageById($id)
	{	
		$sql = "SELECT `image` FROM rom_products WHERE id=$id";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}
	function updateProductById($id, $data)
	{
		$sql = "UPDATE `rom_products` SET title='{$data['title']}', image='{$data['image']}', description='{$data['description']}', price='{$data['price']}', discount_price='{$data['discount_price']}' WHERE id=$id";
		return db_query($sql);
	}
	function deleteProductById($id)
	{
		$sql = "DELETE FROM rom_products WHERE id=$id";
		return db_query($sql);
	}

	function getPreviewImagesById($id)
	{
		$sql = "SELECT image FROM rom_preview_img WHERE product_id=$id";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function getLastProductId()
	{
		$sql = "SELECT id FROM rom_products ORDER BY id DESC LIMIT 1";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}

	function addProductAdditionalPhoto($product_id, $image)
	{
		$sql = "INSERT INTO rom_preview_img (`product_id`, `image`)
		VALUES ('{$product_id}', '{$image}')";
		$res = db_query($sql);
		if(!$res){
			return false;
		}else { 
			return true;
		}
	}

	function getProductAdditionalPhotos($id)
	{
		$sql = "SELECT image FROM rom_preview_img WHERE product_id=$id";
		$dbh = db_query($sql);
		$data = db_fetch_data($dbh);
		if(!empty($data)){
			return $data;
		}else {
			return [];
		}
	}
?>