<?php
	function addNewOrder($data)
	{
		$sql = "INSERT INTO `rom_orders` (product_id, user_name, user_email, user_address, user_city, user_country, user_mail_index, user_phone, spec_key) VALUES 
		('{$data['product_id']}', '{$data['user_name']}', '{$data['user_email']}'
		, '{$data['user_address']}', '{$data['user_city']}', '{$data['user_country']}', 
		'{$data['user_mail_index']}', '{$data['user_phone']}', '{$data['key']}')";
		return db_query($sql);
	}

	function getAllOrders()
	{
		$sql = "SELECT * FROM `rom_orders`";
		$dbh = db_query($sql);
		return db_fetch_data($dbh);
	}

	function deleteOrderByKey($key)
	{
		$sql = "DELETE FROM `rom_orders` WHERE spec_key='{$key}'";
		$dbh = db_query($sql);
	}

	function goodPayment($key) 
	{
		$sql = "UPDATE `rom_orders` SET payment_status='1' WHERE spec_key='{$key}'";
		return db_query($sql);
	}
?>