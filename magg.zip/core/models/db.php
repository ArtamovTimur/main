<?php

	function db_connect()
	{
		$configs = require 'core/configs/main.php';
		$conn = mysqli_connect($configs['db_host'],$configs['db_user'], $configs['db_password'], $configs['db_name']);
		if(!$conn){
			echo 'database connect error!';
		}
		mysqli_query($conn,"SET NAMES utf8");
		mysqli_query($conn, "SET CHARACTER SET utf8");
		return $conn;
	}

	function db_query($sql)
	{
		$link = db_connect();
		$dbh = mysqli_query($link, $sql);
		if(!$dbh){
			echo 'database query error!';
		}
		return $dbh;
	}

	function db_fetch_data($dbh)
	{
		while($arr = mysqli_fetch_assoc($dbh)) {
		    $res[] = $arr;
		}
		return $res;
	}

	function db_get_data_from_table($table)
	{
		$sql = "SELECT * FROM {$table}";
		$dbh = db_query($sql);
		while($arr = mysqli_fetch_assoc($dbh)) {
		    $res[] = $arr;
		}
		return $res;
	}

?>
