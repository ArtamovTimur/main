-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Ноя 07 2017 г., 15:55
-- Версия сервера: 5.6.37-log
-- Версия PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `mag`
--

-- --------------------------------------------------------

--
-- Структура таблицы `rom_images`
--

CREATE TABLE `rom_images` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Структура таблицы `rom_orders`
--

CREATE TABLE `rom_orders` (
  `id` int(11) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_city` varchar(255) NOT NULL,
  `user_country` varchar(255) NOT NULL,
  `user_mail_index` varchar(255) NOT NULL,
  `user_phone` varchar(255) NOT NULL,
  `spec_key` varchar(255) NOT NULL,
  `payment_status` enum('0','1') NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Структура таблицы `rom_preview_img`
--

CREATE TABLE `rom_preview_img` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rom_preview_img`
--

INSERT INTO `rom_preview_img` (`id`, `product_id`, `image`) VALUES
(61, 1, 'assets/img/products/hh8Z6F6A/additional/yK4e8F8T.jpg'),
(62, 1, 'assets/img/products/hh8Z6F6A/additional/R3aQ9QnR.jpg'),
(63, 1, 'assets/img/products/hh8Z6F6A/additional/4HrfZSA6.jpg'),
(64, 1, 'assets/img/products/hh8Z6F6A/additional/RKtybzrr.jpg'),
(65, 21, 'assets/img/products/fD35dS9k/additional/s2ZTt3At.jpg'),
(66, 21, 'assets/img/products/fD35dS9k/additional/dBHsbNEF.jpg'),
(67, 21, 'assets/img/products/fD35dS9k/additional/kb5sa28F.jpg'),
(68, 1, 'assets/img/products/N6k4zEz3/additional/zSsbGfS4.jpg'),
(69, 23, 'assets/img/products/tkES6D9r/additional/bBdQQREh.jpg'),
(70, 23, 'assets/img/products/tkES6D9r/additional/ntzRZ6FF.jpg'),
(71, 23, 'assets/img/products/tkES6D9r/additional/SKeG964d.jpg'),
(72, 23, 'assets/img/products/tkES6D9r/additional/f999eDrN.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `rom_products`
--

CREATE TABLE `rom_products` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` int(11) NOT NULL,
  `discount_price` int(11) NOT NULL,
  `suit_product_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `pub_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `rom_products`
--

INSERT INTO `rom_products` (`id`, `title`, `image`, `description`, `price`, `discount_price`, `suit_product_id`, `author`, `pub_date`) VALUES
(25, 'Роза', 'assets/img/products/6y3ZKQ93/fF44tY7h.jpg', 'Красивая роза', 900, 700, 0, '', '2017-11-07 12:38:34'),
(26, 'd', 'assets/img/products/fnQf32GA/htyy724D.jpg', 'fdfdf', 343, 5454, 0, '', '2017-11-07 12:54:15');

-- --------------------------------------------------------

--
-- Структура таблицы `rom_users`
--

CREATE TABLE `rom_users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('1','2','3') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Дамп данных таблицы `rom_users`
--

INSERT INTO `rom_users` (`id`, `login`, `password`, `role`) VALUES
(1, 'tima', 'tima', '1');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `rom_images`
--
ALTER TABLE `rom_images`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rom_orders`
--
ALTER TABLE `rom_orders`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rom_preview_img`
--
ALTER TABLE `rom_preview_img`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rom_products`
--
ALTER TABLE `rom_products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rom_users`
--
ALTER TABLE `rom_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `rom_images`
--
ALTER TABLE `rom_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `rom_orders`
--
ALTER TABLE `rom_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT для таблицы `rom_preview_img`
--
ALTER TABLE `rom_preview_img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
--
-- AUTO_INCREMENT для таблицы `rom_products`
--
ALTER TABLE `rom_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT для таблицы `rom_users`
--
ALTER TABLE `rom_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
