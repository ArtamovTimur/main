<?php
	session_start();
	
	require 'core/library/main.php';	
	require 'core/library/admin.php';
	require 'core/library/images.php';
	require 'core/models/db.php';
	require 'core/models/orders.php';
	require 'core/models/products.php';
	require 'core/models/users.php';



	if(!isset($_COOKIE['incart'])){ setcookie('incart', '', time()+36000, '/'); }
	if(!isset($_COOKIE['pcount'])){ setcookie('pcount', '', time()+36000, '/'); }
	

	$controllerName = getUrlSegment(0);
	$actionName = getUrlSegment(1);

	if(!empty($controllerName)){
		$controllerName = getUrlSegment(0);
	}else {
		$controllerName = "main";
	}

	if(!empty($actionName)){
		$actionName = "action_" . getUrlSegment(1);
	}else {
		$actionName = "action_index";
	}


	$controllerPath = "core/controllers/" . $controllerName . ".php";
	if(file_exists($controllerPath)){
		require $controllerPath;
		if(function_exists($actionName)){
			$actionName();
		}else {
			show404page();
		}
	}else {
		show404page();
	}

?>