function deleteProduct(){
	$('.delete-product').bind('click',function(){
		var product_block = $(this).parent().parent();
		var cart_count = parseInt($('.cart-count').html());
		$.ajax({
			url: '/products/deleteCart',
			type: 'POST',
			dataType: 'html',
			data: {'id': $(this).attr('data-id')}
		})
		.done(function(data) {
			product_block.remove();
			$('.cart-count').html(cart_count-1);
		})
		.fail(function() {
		})
		.always(function() {
			
		});
	});
}

function getCartProducts()
{
	$.ajax({
		url: '/products/cartProducts',
		type: 'POST',
		dataType: 'html',
		data: {param1: 'value1'},
	})
	.done(function(data) {
		var products = JSON.parse(data);
		var cart_products = $('.delete-product');
		var new_pc  = [];
			$('.cart-count').html(products.length);
			var price = 0;
			for(var j = 0; j <= products.length-1; j++)
			{
			var key = localStorage.key(j);
			price += parseInt(products[j][0].price * parseInt(localStorage.getItem(key)));
			
			$('.main-price-wrap span').html(price + ' ' + '₸');
			var product = `
				<div class="product-in-cart-block">
					<div class="product-in-cart">
						<div class="product-in-cart-title">${products[j][0].title}</div>
						<img src="/${products[j][0].image}" alt="" width="40%" class="product-in-car-img">
									
						<div class="product-in-count"><strong>Количество: <span class="main-price">${localStorage.getItem(key)}</span></strong>&nbsp;</div>
						<div class="price">Цена:&nbsp;${products[j][0].price}</div>
						<div class="delete-product" data-id=${products[j][0].id}>Убрать из корзины</div>
					</div>
				</div>
					`;
				$('.cart-block').append(product);
				$('.all-price').html(price);
			}
			

	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});
}




// Подстветка ссылки активной стараницы

$(document).ready(function(){
	$('.menu span a').each(function() {
		if(this.href == location.href) $(this).parent().addClass('active');
	});

	// инициализация корзины

	getCartProducts();

	// Кнопка наверх

	$('.go-to-top').click(function () {
				$('body,html').animate({
					scrollTop: 0
				}, 1000);
				return false;
	});


	// высота корзины
	var h = $(window).height() + 'px';
	$('.cart-block').css({
		'height': h,
		'z-index': '9999999999',
		'display': 'none',
		'position': 'fixed'
	});

	$('.cart-btn').click(function(){
		var price = parseInt($('.pr').html());
		var all_count = $('.product-in-cart').length-1;
		var product_count = $('pcount');
		var product_price = $('pprice');
		
		for(var i = 0; i <= all_count; i++){
			price += parseInt($('.pcount').eq(i).html()) * parseInt($('.pprice').eq(i).html())
		}
		$('.pr').html(price);
		
		$('.cart-block').show(500);
	});

	$(document).mouseup(function (e) {
	    var container = $(".cart-block");
	    if (e.target!=container[0] && !container.has(e.target).length){
	        container.fadeOut();
	    }
	});

	$('.posBlock').click(function(){
		var imgPath = $(this).parent().find('img').attr('src');
		$('.showImgBlock').css({
			'height': $(window).height(),
			'display': 'block'
		});
		var img = "<img src='" + imgPath+ "' alt=''/>";
		$('.showImgBlock').append(img);
		$(document.body).css('position', 'fixed');
	});

	// превьюшка продукта 

	$('.img-preview').bind('click', function(){
		var imgPath = $(this).attr('src');
		$('.show-img img').attr('src', imgPath);
	});

	// получкение продуктов в корзину





	$('.product').bind('click', function(){
				var id = $(this).attr('id');
				document.location.href='/products/product?id=' + id;
	});

	$('.add-in-cart').click(function(){
		var product_id = $(this).attr('data-id');
		var product_count = $('.count-number').val();
		$.ajax({
			url: '/products/add',
			type: 'POST',
			dataType: 'html',
			data: {'id': product_id, 'product_count': product_count}
		})
		.done(function(data) {
				if(!data) { alert('Уже в корзине!'); return -1;}
				var product_info = JSON.parse(data).product;
				var count = JSON.parse(data).count;
				var product = `
					<div class="product-in-cart-block">
						<div class="product-in-cart">
							<div class="product-in-cart-title">${product_info[0].title}</div>
							<img src="/${product_info[0].image}" alt="" width="40%" class="product-in-car-img">
										
							<div class="product-in-count"><strong>Количество:</strong>&nbsp;${count}</div>
							<div class="price">Цена:&nbsp;${product_info[0].price}</div>
							<div class="delete-product" data-id=${product_info[0].id}>Убрать из корзины</div>
						</div>
					</div>
				`;
				$('.cart-count').html(parseInt($('.cart-count').html()) + 1);
				$('.cart-block').append(product);
				$('.cart-block').show(500);
				var pid = $('.add-in-cart').attr('data-id');
				var pc = $('.count-number').val();
				localStorage.setItem(pid, pc);
				deleteProduct();
		})
		.fail(function() {
			
		})
		.always(function(data) {
			
		});		

	});

	setTimeout('deleteProduct()',2000);
	
	// подгрузка товаров

	$('#get-products').click(function(){
		var last_product_id = $('.product').eq($('.product').length-1)[0].id;
		$.ajax({
			url: '/products/getProducts',
			type: 'POST',
			dataType: 'html',
			data: {last_id: last_product_id},
		})
		.done(function(data) {
			if(data.length == 0) { alert('Пока это все'); return -1;}
			var products = JSON.parse(data);
			
			for(var i = 0; i <= products.length-1; i++){
				var product = `
					<div class="product" id="${products[i]['id']}">
						<img src="/${products[i]['image']}" alt="" width="100%">
						<div class="posBlock">
							<h3>Быстрый просмотр</h3>
						</div>
						<div class="product-title">
							${products[i]['title']}<br>
							<span class="old-price"><strike>${products[i]['price']}</strike></span><span class="price">&nbsp;<?= $allProducts[$i]['discount_price'];?>&nbsp;₸</span>
						</div>
					</div>

				`;
				$('.products-wrap').append(product);
				$('.product').bind('click', function(){
					var id = $(this).attr('id');
					document.location.href='/products/product?id=' + id;
				});
			}
			
		})
		.fail(function() {
		})
		.always(function() {
		});
	});

	// подгрузка изобрадений 


	$('.all-img').click(function(){
		var last_product_id = $('.product').eq($('.product').length-1)[0].id;
		$.ajax({
			url: '/ajax/getImeges',
			type: 'POST',
			dataType: 'html',
			data: {last_id: last_product_id},
		})
		.done(function(data) {
			if(data.length == 0) { alert('Пока это все'); return -1;}
			var products = JSON.parse(data);
			
			for(var i = 0; i <= products.length-1; i++){
				var product = `
					<div class="product" id="${products[i]['id']}">
						<img src="/${products[i]['image']}" alt="" width="100%">
						<div class="posBlock">
							<h3>Быстрый просмотр</h3>
						</div>
						<div class="product-title">
							${products[i]['title']}<br>
							<span class="old-price"><strike>${products[i]['price']}</strike></span><span class="price">&nbsp;<?= $allProducts[$i]['discount_price'];?>&nbsp;₸</span>
						</div>
					</div>

				`;
				$('.products-wrap').append(product);
				$('.product').bind('click', function(){
					var id = $(this).attr('id');
					document.location.href='/products/product?id=' + id;
				});
			}
			
		})
		.fail(function() {
		})
		.always(function() {
		});
		
	});

	$('.go-order a').click(function(e){
		e.preventDefault();
		var products = $('.product-in-cart').length;
		if (products == 0) 
		{
			alert('Корзина пуста!');
		}else {
			document.location.href='/products/order';
		}
	});

	function mainPrice()
	{
		var products = $('.product-in-cart');
		var price = 0;
		for(var i = 0; i <= products.length; i++){
			console.log($('.product-in-count').html());
		}
		//$('.main-price').html();
	}
	
});

