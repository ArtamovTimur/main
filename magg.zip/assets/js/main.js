$(function(){
	$('.menu-block').css('height', $(window).height());
	$('.menu-btn').on('click', function(){
		$('.menu-block').slideToggle('slow');
		$('.menu-btn').hide();
	});
	$(document).mouseup(function(e){
		var container = $('.menu-block');
		if(e.target != container[0] && !container.has(e.target).length){
			container.fadeOut();
			$('.menu-btn').show();
		}
	});
});